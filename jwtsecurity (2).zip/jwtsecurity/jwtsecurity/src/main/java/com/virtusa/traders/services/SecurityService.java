package com.virtusa.traders.services;

public interface SecurityService {

	// to provide current logged-in user and auto login user after registration
	
	String findLoggedInUsername();
	void autoLogin(String username, String password);
}
