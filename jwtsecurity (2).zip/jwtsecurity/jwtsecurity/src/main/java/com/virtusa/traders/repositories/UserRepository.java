package com.virtusa.traders.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.traders.models.User;

public interface UserRepository extends JpaRepository<User,String>{

	User findByUserName(String username);
}
