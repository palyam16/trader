package com.virtusa.traders.services;

import com.virtusa.traders.models.User;

public interface UserService {
	
	void save(User user);
	
	User findByUserName(String username);

}
